package program1;
import java.util.*;
public class array {
	
		public void add_arrays(){
		int a[]= {10,20,30,40,50};
		int sum=0;
		for(int i=0;i<5;i++) {
			sum=sum+a[i];
		System.out.println("add the array elements : "+sum);
		}
		}
		public int length()
		{
			int [][]b={
					{5,6,7,8},
					{1,3,2}};
			int c=b[1].length;
			return c;
		}
		public static void main(String[] args)
		{
			array obj=new array();
			obj.add_arrays();
			int res=obj.length();
			System.out.println("lenght of 2nd row is "+res );
			
		}
		}




