package program1;

public class Typecasting {
	public static void main(String args[])
	{
		System.out.println("Implicit");
		int a=67;
		long b=a;
		System.out.println("int to long "+ b);
		float c=b;
		System.out.println("int to float "+ c);
		long s=256378981;
		double r=s;
		System.out.println("long to double "+r);
		double z=5678904.234;
		float v=(float)z;
		System.out.println("float to long "+v);
		
		
		
		System.out.println("-----------");
		
		System.out.println("Explicit");
		long q= 456789789;
		int p=(int) q;
		System.out.println("long to int "+ p);
		double y= 56789021.99;
		long x=(long) y;
		System.out.println("double to long "+x);
		int f=97;
		char t=(char)f;
		System.out.println("char to int "+t);
		
		
		
		
	}
}
