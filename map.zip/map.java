package program1;
import java.util.*;

public class map {


		public static void main(String[] args) {
			// map
			
			//Hashmap
			HashMap<Integer,String> abc=new HashMap<Integer,String>();      
		      abc.put(11,"mon");    
		      abc.put(21,"tue");    
		      abc.put(31,"wed");   
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(Map.Entry m:abc.entrySet()){    
		       System.out.println(m.getKey()+":"+m.getValue());    
		      }
		      
		     //HashTable
		       
		      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(55,"som");  
		      ht.put(66,"harsh");  
		      ht.put(69,"kisan");  
		      ht.put(77,"aravind");  

		      System.out.println("\nThe elements of HashTable are ");  
		      for(Map.Entry n:ht.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      
		   }  
	}



