package core_java;

public class exception1 {
	public static void main(String[] args){
		System.out.println("start");
		try{
			int arr[]={1,22,33,44};
			System.out.println(arr[10]);
		}
		catch(Exception e){
			System.out.println("something went wrong");
		}
		finally{
			System.out.println("program for exception handling");
		}
	}
}
