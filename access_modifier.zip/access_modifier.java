package program1;

public class access_modifier {
	private int areaofrec (int c, int d)
	{ 
		int res;
		res=c*d;
		return res;
	}
	private void premeterofsquare()
	{
		int r=6;
		int s=3;
		int mul= 2*(r+s);
		System.out.println(mul);
	}
	void display(){
		System.out.println("i am default");
	}
 public static void main(String[] args){
	 access_modifier a1= new access_modifier();
	 a1.areaofrec(8,9);
	 System.out.println("private modifier give the value only within the class");
	 a1.premeterofsquare();
	 a1.display();
 }
}
