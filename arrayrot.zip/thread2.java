package core_java;

public class thread2 implements Runnable {
	public void run()
	{
		System.out.println("Welcome to Runnable interface");
	}
	public static void main(String args[]){
		thread2 d= new thread2();
		Thread t= new Thread(d);
		t.start();
	}
 
}
