package core_java;

public class pillarsofjava1 {
		   int puppyAge;

		   public pillarsofjava1(String name) {
		      // This constructor has one parameter, name.
		      System.out.println("Name chosen is :" + name );
		   }

		   public void setAge( int age ) {
		      puppyAge = age;
		   }

		   public int getAge( ) {
		      System.out.println("Puppy's age is :" + puppyAge );
		      return puppyAge;
		   }

		   public static void main(String[] args) {
		      
			   pillarsofjava1 myPuppy = new pillarsofjava1( "tommy" );
		      myPuppy.setAge( 2 );
		      myPuppy.getAge( );

		      System.out.println("Variable Value :" + myPuppy.puppyAge );
		   }
		}

		      /* Call class method to set puppy's age */


