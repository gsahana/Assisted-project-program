package core_java;
import java.util.*;
public class stack1 {
	    public static void main(String args[])
	    {
	  
	       
	        Stack<String> stack = new Stack<String>();
	  
	       
	        stack.add("welcome");
	        stack.add("for");
	        stack.add("implementation");
	        stack.add("of");
	        stack.add("stack");
	        stack.add("in java");
	  
	       
	        System.out.println("Stack: " + stack);
	  
	        
	        String rem_ele = stack.remove(4);
	  
	        
	        System.out.println("Removed element: "
	                           + rem_ele);
	  
	        
	        System.out.println("Final Stack: "
	                           + stack);
	    }
	}


