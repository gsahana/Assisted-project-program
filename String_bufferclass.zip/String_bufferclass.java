package program1;

public class String_bufferclass{
	public static void main(String[] args){
		StringBuffer obb= new StringBuffer("started java");
		
		obb.append("Phase 1");
		System.out.println(obb);
		
		obb.insert(1,"java");
		System.out.println(obb);
		
		obb.delete(2, 5);
		System.out.println(obb);
		
		obb.replace(1, 3,"python");
		System.out.println(obb);
		
		StringBuilder os=new StringBuilder("good");
		os.append("Morgning");
		System.out.println(os);
		System.out.println(os.length());
		System.out.println(os.charAt(7));
		System.out.println(os.reverse());
		
	}
	}

