package program1;
import java.util.*;

public class methods {
	public static boolean check_leapyear(int year){
		boolean q = (year % 4) == 0;
        boolean p = (year % 100) != 0;
        boolean r = ((year % 100 == 0) && (year % 400 == 0));

        return q && (p || r);
		
	}
	public static void main(String[] args){
		Scanner a= new Scanner(System.in);
		int b=a.nextInt();
		System.out.println(check_leapyear(b));
		
	}

}
