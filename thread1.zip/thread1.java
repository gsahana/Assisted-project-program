package core_java;

public class thread1 extends Thread {
	public void run()
	{
		System.out.println("Welcome to extending the thread class");
	}
	public static void main(String args[])
	{
		thread1 s=new thread1();
		s.start();
		
	}

}
