package core_java;


import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;
public class createfile1 {

    public static void main(String[] args) throws IOException
    {
        createFileUsing();
        
    }
 
    private static void createFileUsing() throws IOException
    {
          File f1 = new File("C://New folder//testFile1.txt");
  
          //Create the file
          if (f1.createNewFile()){
            System.out.println("File is created!");
          }else{
            System.out.println("File already exists.");
          }
           
          //Write Content
          FileWriter writer = new FileWriter(f1);
          writer.write("Test data");
          writer.close();
    }
 
   
}



