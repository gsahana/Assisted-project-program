package program1;
import java.util.*;

public class collection {
	public void array_list()
	{ 
		System.out.println("ArrayList collection");
		ArrayList<String>months=new ArrayList<String>();
		months.add("january");
		months.add("Febuary");
		months.add("March");
		months.add("April");
		months.add("November");
		months.add("December");
		System.out.println(months);
		
	}
	public void hash_set()
	{
		System.out.println("\n");
		System.out.println("HashSet Collection");
		HashSet<Integer> num=new HashSet<Integer>();  
	       num.add(111);  
	       num.add(123);  
	       num.add(142);
	       num.add(134);
	       System.out.println(num);
	}
	public void linked_list()
	{
	      System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<String> frds=new LinkedList<String>();  
	      frds.add("sam");  
	      frds.add("renu"); 
	      frds.add("harini");
	      frds.add("priya");
	      Iterator<String> itr=frds.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  
	      }

	}
	public static void main(String[] args)
	{
		collection obj= new collection();
		obj.array_list();
		obj.hash_set();
		obj.linked_list();
		
	}

}
